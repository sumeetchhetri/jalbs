package com.cpfj;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public class arr
{
	@XStreamAsAttribute
	String type;
	entry[] entries;
}
