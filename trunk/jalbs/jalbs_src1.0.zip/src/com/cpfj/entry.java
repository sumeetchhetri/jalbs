package com.cpfj;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public class entry
{
	@XStreamAsAttribute
	String key;
	String value;
}
